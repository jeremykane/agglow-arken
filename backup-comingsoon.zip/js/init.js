//Hook up the tweet display

$(document).ready(function() {
						   
	$(".countdown").countdown({
				date: "30 nov 2021 20:30:00",
				format: "on"
			},
			
			function() {
				// callback function
			});

});	